#DF4Scratch Manual

## Compatible Operating System
Windows 7, 8 and 10. Some of windows XP Professional version may be compatible with Scratch.  
System installed via Ghost might have unexpected issues.

## Installation Instructions

Please install [Arduino](https://www.arduino.cc/en/Main/Software) and [Scratch](https://scratch.mit.edu/scratch2download/) first.

This soft ware is a green software. We offer a helper process to facilitate the communications between Scratch and Arduino.  

## Run Scratch for Arduino

### Run Example for Arduino

1. Connect Arduino board to your computer
2. Make sure your Arduino board has StandardFirmata uploaded(You can find it shipped with Arduino，at File->Example->Firmata->StandardFirmata)
3. Go to the installation folder and execute `Launch Arduino Communication Service`
4. Open the `Arduino Example.sb2` project file for Scratch
5. （Optional）Connect a Servo to pin 10
6. （Optional）Connect a LED to pin 13, with a 10K resistor.
7. （Optional）Connect a 1602 LCD Screen via I2C
8. Click on the green flag in Scratch and watch the board in action. If your board has a on-board LED on pin 13, then you can see it blinking.


### Open Your Own Project File

1. Connect your Arduino to your computer
2. Make sure your Arduino board has StandardFirmata uploaded(You can find it shipped with Arduino，at File->Example->Firmata->StandardFirmata)
3. Go to the installation folder and execute `Launch Arduino Communication Service`
4. Open your Scratch project file


### Build Your Own Project

#### Basic Procedure
1. Connect your board, upload Firmata and open the example project
2. Make change to the example project
3. Please ***do not*** delete the `DFRobot` extension block set in `more blocks`
4. Please ***do not*** delete the `Pin readings` Sprite
5. Save your project as a new project


#### I Am Feeling Hacky
1. Connect your board, upload Firmata and open the example project
2. Hold `Shift` key and click on the `open` menu item, then click on `Import exprimental HTTP extension`。Then import the `DF4Scratch.s2e` file in the `contents` directory.
3. Go to the installation folder and execute `Launch Arduino Communication Service`
4. Build your project
5. Save your project

Please note you need to set up your own variables to be able to read the pin values. We still recommend making changes to the example project.


## Voretx Manual


### Run Vortex Example

1. Connect Vortex to your computer, either via micro USB cable or bluetooth adapter.
2. Make sure you have uploaded the default vortex firmware. You can user IOS apps provided by DFRobot to upload the latest firmware.
3. Go to the installation folder and execute `Launch Vortex Communication Service`
4. Open the `Vortex Example.sb2` project file for Scratch 
5. Click on the green flag in Scratch and Vortex will start to dance.


### Open Your Own Project File

1. Connect Vortex to your computer, either via micro USB cable or bluetooth adapter.
2. Make sure you have uploaded the default vortex firmware. You can user IOS apps provided by DFRobot to upload the latest firmware.
3. Go to the installation folder and execute `Launch Vortex Communication Service`
4. Open your own project

### Build Your Own Project

#### Basic Procedure
1. Connect Vortex to your computer, either via micro USB cable or bluetooth adapter.
2. Make sure you have uploaded the default vortex firmware. You can user IOS apps provided by DFRobot to upload the latest firmware.
3. Go to the installation folder and execute `Launch Vortex Communication Service`
4. Open the `Vortex Example.sb2` project file for Scratch 
5. Please ***do not*** delete the `DFRobot` extension block set in `more blocks`
6. Make changes to the example project
7. Save the project as a new project 

### Share Your Projects

Scratch's built-in sharing function allows you to share your projects in your account.


### FAQ

1. The Arduino board is not responding
	* Make sure your board has StandardFirmata program uploaded.
    * Check if the communication is good. You can check the round dot after you click on `More blocks` in Scratch and see the color. If it is red, it means the communication is broken.
	* If it is red:
	1. close Scratch window.
	2. Execute `Stop Communication Services`
	3. Unplug the Arduino board from your computer then re-plug it after a few seconds.
	4. Execute `Launch Arduino Communication Service`
	5. Reopen `Arduino Example.sb2`
	
2. What if I deleted the example files
	* We have an `example` folder holding copies of them
	* You can download DF4Scratch again and overwrite the examples
3. What if I deleted the DFRobot plugcin
	* In Scratch, hold `Shift` key and click on the `open` menu item, then click on `Import exprimental HTTP extension`。Then import the `DF4Scratch.s2e` file in the `contents` directory.
4. How to upload the Firmata program
	* Close Scartch, and execute `Stop Communication Services`
	* Connect your Arduino board to your computer
	* Open Arduino program, go to menu File->Example->Firmata->StandardFirmata
	* Choose correct port and board type
	* Click on `upload` button
5. How to uninstall
	* Execute `Stop Communication Services` then delete the whole folder