var serialPort = require("serialport");
var SerialPort = serialPort.SerialPort;

serialPort.list(function (err, ports) {
  ports.forEach(function(port) {
    console.log(port.comName);
    console.log(port.pnpId);
    console.log(port.manufacturer);
	
	if (port.manufacturer.toLowerCase().indexOf("arduino") > -1){
		console.log("arduino: " + port.comName);
		

		var sp = new SerialPort(port.comName, {
			disconnectedCallback: function(){
				console.log("pulled out!");
			}	
		});

	}
  });
});


