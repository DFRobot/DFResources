var five = require("johnny-five");
var board = new five.Board();

board.on("ready", function() {
  var led = new five.Pin({pin: 13,mode: 0});

  // Add servo to REPL (optional)
  this.repl.inject({
    led: led
  });

  //led.on("data", function(data){console.log("data:" +data);});
  led.on("high", function(data){console.log("high:" +data);});
  led.on("low", function(data){console.log("low:" +data);});
  // Servo API

  // min()
  //
  // set the servo to the minimum degrees
  // defaults to 0
  //
  // eg. servo.min();

  // max()
  //
  // set the servo to the maximum degrees
  // defaults to 180
  //
  // eg. servo.max();

  // center()
  //
  // centers the servo to 90°
  //
  // servo.center();

  // to( deg )
  //
  // Moves the servo to position by degrees
  //
  // servo.to( 90 );

  // step( deg )
  //
  // step all servos by deg
  //
  // eg. array.step( -20 );

  //servo.to(0);
  //servo.sweep();
  
});
