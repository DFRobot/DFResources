#Windows XP安装Scratch 2蓝屏怎么办

***如果已经安装过Scratch2，您可续选择跳过这个步骤***

根据Scratch2 [官网描述](http://scratch.mit.edu/scratch2download/)，由于Adobe Air平台的一些更新导致Scratch2开始运行时会产生错误。解决的方法是再次安装Scratch2。

如果您的计算机系统是Windows XP，这个错误可能导致计算器蓝屏或者自动重启。接下来将介绍如何解决这个错误。

##安装步骤

### 1.首次安装Scratch2

DF4Scratch的安装程序会推荐同时安装Scratch2，勾选*安装Scratch*后会自动打开Scratch2安装界面。

![](.\DF4ScratchInstall.png)

首次安装Scratch2时，默认会勾选*安装后启动应用程序*选项。

请务必确保该选项**被勾选**

![](.\install_checked.png)

安装完毕后Scratch2会自动运行。如果运行没有错误，那么就可以跳过下面的步骤。否则请继续以下的步骤。

### 2.再次安装Scratch2

如果您的计算机不幸在Scratch第一次启动之后发生错误，请再次安装Scratch2。

再次安装Scratch可以使用我们提供的**安装Scratch**程序。

![]( .\shortcut.png )

再次安装Scratch2时，默认会勾选*安装后启动应用程序*选项。

请务必确保该选项**不被勾选**

![](.\install_unchecked.png)

完成安装之后可以启动DF4Scratch。