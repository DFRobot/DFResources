#DF4Scratch使用说明

##支持系统
官方完整版的Windows 7，8，10以及部分XP专业版系统。  
Ghost版Windows系统可能会出现通讯问题。

## 安装说明

请先安装[Arduino](https://www.arduino.cc/en/Main/Software)和[Scratch](https://scratch.mit.edu/scratch2download/)

本软件为绿色免安装版。由于Scratch无法直接连接Arduino，故需要我们的插件程序提供协助。  


## Arduino使用说明

### 运行Arduino简单样例

1. 把Arduino连接上计算机
2. 确认Arduino烧录StandardFirmata协议(Arduino官方程序自带，位于文件->示例->Firmata->StandardFirmata)
3. 完毕之后进入安装目录，然后双击运行`启动Arduino后台服务`
4. 打开`简单Arduino例子`项目文件
5. （可选）连接舵机到10号针脚
6. （可选）连接LED灯，并且串联10K电阻到13号针脚
7. （可选）使用I2C方式连接1602LCD液晶显示屏
8. 点击绿色旗帜按钮，观察Arduino的变化。如果Arduino板载有代表13号针脚的LED，可以观察到LED闪烁。


### 打开自己的项目

1. 首先连接Arduino
2. 然后双击运行`启动Arduino后台服务`
3. 双击打开您的项目文件


### 创建自己的项目

#### 方法一
1. 首先连接Arduino，然后打开DF4Scratch.sb2，打开样例程序
2. 按照需要修改Scratch工程
3. 注意请不要删除“更多模块”下的“DFRobot”插件
4. 注意请不要删除“引脚读书”角色
5. 修改完毕把工程另存为其他工程


### 方法二
1. 首先连接Arduino，然后直接打开Scratch程序
2. 按住Shift键并单击文件菜单按钮，选择“Import exprimental HTTP extension”。然后选择DF4scratch安装目录下的`DF4scratch_zh.s2e`文件
3. 从开始菜单单击“运行Arduino链接器”
4. 开始创建项目
5. 保存项目

注意方法二并不能提供便捷的引脚读数，需要像默认样例工程一样建立多个变量并把引脚读书赋值到变量。  
建议使用方法一提高效率。


## Voretx使用说明


### 运行Vortex简单样例

1. 把Vortex连接上计算机，可以通过蓝牙连接或者物理连线
2. 确认Vortex内部烧录了出厂固件。可以通过WhenDo重置Vortex出厂固件
3. 完毕之后进入安装目录，然后双击运行`启动Vortex后台服务`
4. 打开`简单Vortex例子`项目文件
5. 点击绿色旗帜按钮，Vortex会开始跳编号为1号的舞蹈


### 打开自己的项目

1. 首先连接Vortex，可以通过蓝牙连接或者物理连线
2. 然后双击运行`启动Vortex后台服务`
3. 双击打开您的项目文件

### 创建自己的项目

#### 方法一
1. 首先连接Vortex，然后打开`简单Vortex例子.sb2`，打开样例程序
2. 按照需要修改Scratch工程
3. 注意请不要删除“更多模块”下的“DFRobot”插件
4. 注意请不要删除“引脚读书”角色
5. 修改完毕把工程另存为其他工程


### 方法二
1. 首先连接Vortex，然后直接打开Scratch程序
2. 按住Shift键并单击文件菜单按钮，选择“Import exprimental HTTP extension”。然后选择安装目录下`content`文件夹中的`vortex_zh.s2e`文件  
3. 然后双击运行`启动Vortex后台服务`
4. 开始创建项目
5. 保存项目



### 分享自己的项目

使用Scratch内置的项目分享功能可以把工程文件分享到Scratch的账号。


### 常见问题FAQ

1. 打开DF4Scratch之后开发板没有反应
	* 确认Arduino开发版中烧录了StandardFirmata固件程序
    * 确认连接是否正常，点击“更多模块”，检查DFRobot右侧是否有绿色圆点。绿色表示连接正常，红色表示断开。
	* 如果显示红色，关闭Scratch窗口
	* （可选）运行`绿色安装`程序
	* 拔出Arduino开发版，过几秒钟之后再连接开发版
	* 重新打开样例程序
2. 误删除或者覆盖了默认样例程序怎么办
	* 在安装目录下还有example文件夹，`DF4Scratch.sb2`就是样例程序
	* 可以重新安装DF4scratch
3. 误删除了DF4scratch插件怎么办
	* 在Scratch中，按住Shift键并单击文件菜单按钮，选择“Import exprimental HTTP extension”。然后选择DF4scratch安装目录下的`DF4scratch_zh.s2e`文件
4. 如何烧录Firmata固件
	* 连接Arduino开发版
	* 使用Arduino软件，打开“文件->示例->Firmata->StandardFirmata”
	* 单击上传按钮进行上传
5. 无法烧录StandardFirmata程序
	* 尝试运行`绿色卸载`程序之后，重新插拔Arduino再烧录。
	* 烧录完毕之后再运行`绿色安装`程序
6. 如何卸载插件
	* 运行`绿色卸载`程序之后删除文件夹即可。